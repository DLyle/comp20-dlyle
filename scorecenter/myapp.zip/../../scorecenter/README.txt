David Lyle

To my knowledge all aspects of this project have been correctly implemented

I discussed this assignment with Sam Dushay, Amadou Crookes and Dennis Chen

I spent about 10 hours on this assignment


