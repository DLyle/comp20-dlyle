var express = require('express');
//var MONGOLAB_URI =
//"mongodb://david.lyle@tufts.edu:D_yscedou0630@ds037047.mongolab.com:37047/heroku_app14907857"

var app = express.createServer(express.logger());
app.use(express.bodyParser());
var mongoUri = process.env.MONGOLAB_URI || 
               process.env.MONGOHQ_URL  ||
               'mongodb://localhost/scorecenter';
var mongo = require('mongodb');
var db = mongo.Db.connect(mongoUri, function (error, databaseConnection) {
         db = databaseConnection;
});
/*
app.all('/submit.json', function(request, response, next){
  response.header("Access-Control-Allow-Origin", "*");
  response.header("Access-Control-Allow-Headers","X-Requested-With");
  next();
});

app.all('/highscores.json', function(request, response, next){
  response.header("Access-Control-Allow-Origin", "*");
  response.header("Access-Control-Allow-Headers","X-Requested-With");
  next();
});
*/
app.get('/highscores.json', function(request, response) {
  response.header("Access-Control-Allow-Origin", "*");
  response.header("Access-Control-Allow-Headers","X-Requested-With");
  db.collection("scores",function(er,collection){
    var game_title = request.param('game_title');
    var cursor = collection.find();
    if(!(game_title === undefined)){
      cursor = collection.find({"game_title":game_title});
    }
    cursor.limit(10);
    sorted = cursor.sort({"score":-1});
    sorted.toArray(function(er,array){
      response.send(array);
    });
  });
});

app.get('/userscores.json',function(request,response){
  response.header("Access-Control-Allow-Origin", "*");
  response.header("Access-Control-Allow-Headers","X-Requested-With");
  db.collection("scores",function(er,collection){
    var username = request.param('username');
    var cursor = collection.find({"username":username});
    cursor.toArray(function(er,array){
      response.send(array);
    });
  });
});
        
app.get('/usersearch', function(request, response) {
  response.header("Access-Control-Allow-Origin", "*");
  response.header("Access-Control-Allow-Headers","X-Requested-With");
  response.send(
  '<!DOCTYPE html><html><head>'+
  '<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>'+
  '<script>'+
  'function dispScores(){'+
   ' var user = document.getElementById("input").value;'+
  '$.get("http://agile-cliffs-3152.herokuapp.com/userscores.json?username="+user,function(data){'+
   ' var userGames = data;'+  
   ' var output = "";'+
    'for(var i = 0; i < userGames.length;i++){'+
     ' if(userGames[i]["username"] == user){'+
      'var game = userGames[i]["game_title"];'+
     ' var score = userGames[i]["score"];'+
    '  output += "<p>"+game+": "+score+"</p>";'+ 
   '   }'+
  '  }'+
 '   document.getElementById("scores").innerHTML = output;'+
'  });'+
'}</script>'+
  '</head><body>'+
  '<input type="text" id="input"></input>'+
  '<input type="submit" id="submit" onclick = "dispScores()"></input>'+
  '<div id=scores></div></body></html>');
});

app.get('/', function(request, response) {
  db.collection("scores",function(er,collection){
    var cursor = collection.find();
    cursor.toArray(function(er,array){
      var output = "<!DOCTYPE html><html><head></head><body><h1>Scores</h1>";
      for(var i = 0; i < array.length; i++){
        var game = array[i]["game_title"];
        var score = array[i]["score"];
        output += "<p>Game: "+game+" Score: "+score+"</p>";
      }
      output += "</body></html>"
      response.send(output);
    });
  });
});

app.post('/submit.json', function(request,response){
  response.header("Access-Control-Allow-Origin", "*");
  response.header("Access-Control-Allow-Headers","X-Requested-With");
  var game_title = request.param('game_title');
  var username   = request.param('username');
  var score      = parseInt(request.param('score'));
  db.collection("scores",function(er,collection){
    var data = {"game_title":game_title,"username":username,"score":score};
    var time = new Date();
    data["created_at"] = String(time);
    collection.insert(data);
    response.send();
  });
});

var port = process.env.PORT || 5000;
app.listen(port, function() {
  console.log("Listening on " + port);
});
